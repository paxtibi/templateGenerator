import angular from 'angular';
import uiRouter from '@uirouter/angularjs';
import template from '../basePageController/baseHandleController.html';
import controller from './MCEMaintainHandle.controller';
import './MCEMaintainHandle.scss';

let MCEMaintainHandlePageDescription = {
  bindings: {},
  template,
  controller
};

export default MCEMaintainHandlePageDescription; 

let MCEMaintainHandleModule = angular.module('MCEMaintainHandle', [
  uiRouter
]);
MCEMaintainHandleModule.config(($stateProvider, $urlRouterProvider) => {
  "ngInject";
  console.log("State provided for MCEMaintainHandle");
  $stateProvider.state('MCEMaintainHandle', {
    url: '/MCEMaintainHandle',
    component: 'MCEMaintainHandle',
    params: {     
      'parameters': null
    }
  });
})
MCEMaintainHandleModule.component('MCEMaintainHandle', MCEMaintainHandlePageDescription)
export default MCEMaintainHandleModule.name;
