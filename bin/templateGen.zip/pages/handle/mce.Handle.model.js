
export default class MCEMaintainView  {

  constructor() {
    "ngInject";
    this.pagename = 'MCEMaintain';
  }
  
}
