import BaseSearchController from "../basePageController/baseSearchController";
import MCEMaintainView from "./MCEMaintain.view";
import MCEMaintainModel from "./MCEMaintain.model";

class MCEMaintainSearchPageController extends BaseSearchController {

  constructor(commonServices, MCEServices, propertyServices, security, notificationWrapper, messageBoxService, modelService, $scope, $uibModal, geoAreeServices, $q, $translate) {
    "ngInject";
    super('MCE', commonServices, security, notificationWrapper, messageBoxService, modelService, $scope, $uibModal, geoAreeServices, $q, $translate);
    this.model = new  MCEMaintainModel();
    this.view = new  MCEMaintainView();
  }
  
}

export default MCEMaintainSearchPageController;