import angular from 'angular';
import uiRouter from '@uirouter/angularjs';
import template from '../basePageController/baseSearchController.html';
import controller from './MCEMaintainSearch.controller';
import './MCEMaintainSearch.scss';

let MCEMaintainSearchPageDescription = {
  bindings: {},
  template,
  controller
};

export default MCEMaintainSearchPageDescription; 

let MCEMaintainSearchModule = angular.module('MCEMaintainSearch', [
  uiRouter
]);
MCEMaintainSearchModule.config(($stateProvider, $urlRouterProvider) => {
  "ngInject";
  console.log("State provided for MCEMaintainSearch");
  $stateProvider.state('MCEMaintainSearch', {
    url: '/MCEMaintainSearch',
    component: 'MCEMaintainSearch',
    params: {     
      'parameters': null
    }
  });
})
MCEMaintainSearchModule.component('MCEMaintainSearch', MCEMaintainSearchPageDescription)
export default MCEMaintainSearchModule.name;
