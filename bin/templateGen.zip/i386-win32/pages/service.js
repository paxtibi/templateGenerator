import BaseServices from './baseServices';

  /**
   */
export default class <%class-prefix%>Services extends BaseServices {
  /**
   * Service constructor  
   */
  
  constructor($http, appConstants, $q, $uibModal, notificationWrapper, $translate) {
    "ngInject";
    super($http, appConstants, $q, $uibModal, notificationWrapper, $translate);
    this.endpoint = {
      'search': '<%searchurl%>',
      'cancel': '<%cancelurl%>',
      'download': '<%downloadurl%>',
      'insertMassiveActivity': '<%inserturl%>',
      'insertMassiveActivityFile': '<%insertfileurl%>'
    }
  }
  /**
   */
  searchMassiveActivity(searchFilters) {
    var payload = {
      "user": null,
      'input': searchFilters
    }
    var endpoint = this.endpoint.searchMassiveActivity;
    var request = {
      dataType: 'json',
      method: 'POST',
      url: endpoint,
      data: payload
    };
    return this.executeRequest(request);
  }; // searchMassiveActivity

  /**
   */
  cancelMassiveActivity(id) {
    var endpoint = this.endpoint.cancelMassiveActivity;
    endpoint = endpoint.replace('{{maId}}', id);
    var request = {
      method: 'DELETE',
      url: endpoint,
      data: ''
    };
    return this.executeRequest(request);
  }; //cancelMassiveActivity

  /**
   */
  insertMassiveActivity(requestData) {
    console.log("insertMassive");
    var endpoint = this.endpoint.insertMassiveActivity;
    var request = {
      method: 'POST',
      url: endpoint,
      data: {
        input: requestData
      }
    };
    return this.executeRequest(request);
  } //insertMassiveActivity

  /**
   */
  insertMassiveActivityFile(inputData) {
    console.log("insertMassiveByFile");
    var endpoint = this.endpoint.insertMassiveActivityFile;
    var request = {
      method: 'POST',
      url: endpoint,
      data: inputData
    };
    return this.executeUpload(request);
  } //insertMassiveActivityFile

  /**
   */
  downloadDiscardedFile(id) {
    console.log("downloadDiscardedFile:", id);
    var endpoint = this.endpoint.downloadDiscardedFile;
    endpoint = endpoint.replace('{{maId}}', id);
    return endpoint;
  }; //downloadDiscardedFile
  
}
