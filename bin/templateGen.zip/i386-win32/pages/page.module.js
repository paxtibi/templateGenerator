import angular from 'angular';
import uiRouter from '@uirouter/angularjs';
import template from './<%module-name%>.template.html';
import controller from './<%module-name%>.pagecontroller';
import './<%module-name%>.scss';

let <%module-name%>Page = {
  bindings: {},
  template,
  controller
};

export default <%module-name%>Page;


let <%module-name%>Module = angular.module('<%project-name%>.<%module-name%>', [
  uiRouter
]);

<%module-name%>Module.config(($stateProvider, $urlRouterProvider) => {
  "ngInject";
  $urlRouterProvider.otherwise('/');
  $stateProvider.state('<%state-url%>', {
    url: ''<%state-url%>/',
    component: '<%module-name%>Page'
  });
});
<%module-name%>Module.component('<%module-name%>',<%module-name%>Page);
  

export default <%module-name%>Module.name;
