export default class <%class-prefix%>PageController {
  constructor() {
    this.name = '<%module-name%>';
  }
}
