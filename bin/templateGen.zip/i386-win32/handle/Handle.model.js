
export default class <%page-name%>View  {

  constructor() {
    "ngInject";
    this.pagename = '<%page-name%>';
  }
  
}
