import angular from 'angular';
import uiRouter from '@uirouter/angularjs';
import template from '../basePageController/baseHandleController.html';
import controller from './<%page-name%>Handle.controller';
import './<%page-name%>Handle.scss';

let <%page-name%>HandlePageDescription = {
  bindings: {},
  template,
  controller
};

export default <%page-name%>HandlePageDescription; 

let <%page-name%>HandleModule = angular.module('<%page-name%>Handle', [
  uiRouter
]);
<%page-name%>HandleModule.config(($stateProvider, $urlRouterProvider) => {
  "ngInject";
  console.log("State provided for <%page-name%>Handle");
  $stateProvider.state('<%page-name%>Handle', {
    url: '/<%page-name%>Handle',
    component: '<%page-name%>Handle',
    params: {     
      'parameters': null
    }
  });
})
<%page-name%>HandleModule.component('<%page-name%>Handle', <%page-name%>HandlePageDescription)
export default <%page-name%>HandleModule.name;
