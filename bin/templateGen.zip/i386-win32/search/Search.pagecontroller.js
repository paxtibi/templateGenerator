import BaseSearchController from "../basePageController/baseSearchController";
import <%page-name%>View from "./<%page-name%>.view";
import <%page-name%>Model from "./<%page-name%>.model";

class <%page-name%>SearchPageController extends BaseSearchController {

  constructor(commonServices, <%class-prefix%>Services, propertyServices, security, notificationWrapper, messageBoxService, modelService, $scope, $uibModal, geoAreeServices, $q, $translate) {
    "ngInject";
    super('<%class-prefix%>', commonServices, security, notificationWrapper, messageBoxService, modelService, $scope, $uibModal, geoAreeServices, $q, $translate);
    this.model = new  <%page-name%>Model();
    this.view = new  <%page-name%>View();
  }
  
}

export default <%page-name%>SearchPageController;