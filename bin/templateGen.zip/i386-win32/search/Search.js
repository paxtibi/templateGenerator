import angular from 'angular';
import uiRouter from '@uirouter/angularjs';
import template from '../basePageController/baseSearchController.html';
import controller from './<%page-name%>Search.controller';
import './<%page-name%>Search.scss';

let <%page-name%>SearchPageDescription = {
  bindings: {},
  template,
  controller
};

export default <%page-name%>SearchPageDescription; 

let <%page-name%>SearchModule = angular.module('<%page-name%>Search', [
  uiRouter
]);
<%page-name%>SearchModule.config(($stateProvider, $urlRouterProvider) => {
  "ngInject";
  console.log("State provided for <%page-name%>Search");
  $stateProvider.state('<%page-name%>Search', {
    url: '/<%page-name%>Search',
    component: '<%page-name%>Search',
    params: {     
      'parameters': null
    }
  });
})
<%page-name%>SearchModule.component('<%page-name%>Search', <%page-name%>SearchPageDescription)
export default <%page-name%>SearchModule.name;
